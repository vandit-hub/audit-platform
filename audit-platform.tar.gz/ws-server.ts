#!/usr/bin/env node
import 'dotenv/config';
import './src/websocket/server';

console.log('Starting WebSocket server...');